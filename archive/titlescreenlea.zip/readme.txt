
--For years Lea stood tall despite all the odds, entrusting her back to us. But wouldn't it be great if she could offload some of that pressure from her legs onto those nice railings that were always so inviting to sit on and breath in all that beauty that is the coast of the Croissant?

--This is a very basic mod(asset replacer) with a simple goal of replacing Lea's pose on the title screen with a different one.


the art work is made by me
the tech part made possible by cool members of "CrossCode Modding" discord server!

